Follow the next steps to install the filesystem uploader if you’re using Windows:

1) Go to ESP32FS-1.0.zip file.

2) Find your Sketchbook location. In your Arduino IDE, go to File > Preferences and check your Sketchbook location. 

3) Go to the sketchbook location, and create a tools folder.

4) Unzip the downloaded .zip folder. Open it and copy the ESP32FS folder to the tools folder you created in the previous step. 

5) Finally, restart your Arduino IDE.

To check if the plugin was successfully installed, open your Arduino IDE. Select your ESP32 board, go to Tools and check that you have the option “ESP32 Sketch Data Upload“.   

https://randomnerdtutorials.com/install-esp32-filesystem-uploader-arduino-ide/ 

Avem nevoie de aceasta pentru a putea incarca pagina index.html. Mai intai trebuie incarcata pagina pe placa si apoi codul.